import os
import subprocess
from graphviz import Digraph


def mostrar_menu():
    print("\n=== SIMULADOR DE AUTÓMATAS FINITOS ===")
    print("1. Crear un autómata y ver su gráfica")
    print("2. Mostrar cinco palabras conocidas")
    print("3. Probar si una palabra es reconocida")
    print("4. Salir")


def graficar_automata(automata):
    Q = automata["Q"]
    delta = automata["delta"]
    q0 = automata["q0"]
    F = automata["F"]

    # Crear grafo dirigido de izquierda a derecha (LR)
    dot = Digraph(name="Automata", format="png")
    dot.attr(rankdir="LR", dpi="150")
    dot.attr(
        "node",
        fontname="Arial",
        fontsize="12",
        style="filled",
        fillcolor="#EBF1F6",
        color="#1F3864",
        penwidth="1.5",
    )
    dot.attr(
        "edge",
        fontname="Arial",
        fontsize="11",
        color="#1F3864",
        penwidth="1.5",
    )

    # 1. Nodo invisible para la flecha inicial sin origen
    dot.node("inicio", label="", shape="none", width="0", height="0")

    # 2. Dibujar estados (doble círculo para finales, círculo simple para el resto)
    for estado in Q:
        forma = "doublecircle" if estado in F else "circle"
        dot.node(estado, label=estado, shape=forma)

    # Conectar flecha inicial hacia q0
    dot.edge("inicio", q0)

    # 5. Agrupar transiciones que comparten (origen, destino)
    aristas_agrupadas = {}
    for (origen, simbolo), destino in delta.items():
        aristas_agrupadas.setdefault((origen, destino), []).append(simbolo)

    # 3 y 4. Dibujar flechas (bucles y flechas curvas en ambos sentidos)
    for (origen, destino), simbolos in aristas_agrupadas.items():
        etiqueta = ", ".join(simbolos)
        dot.edge(origen, destino, label=f" {etiqueta} ")

    print("\nMostrando la gráfica del autómata...")
    ruta_dot = r"C:\Program Files\Graphviz\bin\dot.exe"

    try:
        # Guardar código fuente del grafo y renderizar llamando directo a dot.exe
        dot.save("automata.gv")
        subprocess.run(
            [ruta_dot, "-Tpng", "automata.gv", "-o", "automata_grafica.png"],
            check=True,
        )
        # Eliminar el archivo temporal .gv
        if os.path.exists("automata.gv"):
            os.remove("automata.gv")
        # Abrir la imagen generada en Windows
        os.startfile("automata_grafica.png")
    except Exception as e:
        print(f"Error al generar la gráfica: {e}")


def crear_automata():
    print("\n=== MÓDULO 1: CONSTRUCCIÓN DEL AUTÓMATA ===")

    # 1. Estados (Q)
    while True:
        entrada_q = input("Estados Q (separados por comas): ")
        estados = [e.strip() for e in entrada_q.split(",") if e.strip()]
        if not estados:
            print("Error: Debe ingresar al menos un estado.")
        elif len(estados) != len(set(estados)):
            print("Error: No se aceptan nombres de estados repetidos.")
        else:
            break

    # 2. Alfabeto (Σ)
    while True:
        entrada_sigma = input("Alfabeto Σ (símbolos separados por comas): ")
        alfabeto = [s.strip() for s in entrada_sigma.split(",") if s.strip()]
        if not alfabeto:
            print("Error: El alfabeto no puede estar vacío.")
        elif any(len(s) != 1 for s in alfabeto):
            print("Error: Cada símbolo debe ser un único carácter.")
        elif len(alfabeto) != len(set(alfabeto)):
            print("Error: Los símbolos no pueden repetirse.")
        else:
            break

    # 3. Función de transición (δ)
    print("Función de transición δ:")
    transiciones = {}
    for estado in estados:
        for simbolo in alfabeto:
            while True:
                destino = input(f"  δ({estado}, {simbolo}) = ").strip()
                if destino in estados:
                    transiciones[(estado, simbolo)] = destino
                    break
                else:
                    print(
                        f"Error: El estado '{destino}' no pertenece a Q = {{{', '.join(estados)}}}. Intente de nuevo."
                    )

    # 4. Estado inicial (q0)
    while True:
        q0 = input("Estado inicial q0: ").strip()
        if q0 in estados:
            break
        else:
            print(
                f"Error: El estado inicial '{q0}' no pertenece a Q = {{{', '.join(estados)}}}. Intente de nuevo."
            )

    # 5. Estados finales (F)
    while True:
        entrada_f = input("Estados finales F (separados por comas, o Enter si no hay): ")
        finales = [f.strip() for f in entrada_f.split(",") if f.strip()]

        invalidos = [f for f in finales if f not in estados]
        if invalidos:
            print(f"Error: Los estados {invalidos} no pertenecen a Q. Intente de nuevo.")
        elif len(finales) != len(set(finales)):
            print("Error: No repita estados finales.")
        else:
            if not finales:
                print(
                    "Advertencia: No indicó estados finales; el autómata no reconocerá ninguna palabra."
                )
            break

    # --- MOSTRAR EL AUTÓMATA (5-TUPLA Y TABLA) ---
    q_str = ", ".join(estados)
    sigma_str = ", ".join(alfabeto)
    f_str = ", ".join(finales) if finales else "∅"

    print("\nAutómata construido:")
    print(f"  M = ({{{q_str}}}, {{{sigma_str}}}, δ, {q0}, {{{f_str}}})\n")

    # Calcular anchos para alinear columnas
    ancho_estado = max(len(e) for e in estados)
    ancho_col = max(ancho_estado, max(len(s) for s in alfabeto)) + 2

    # Encabezado de la tabla
    encabezado_izq = f"    {'δ':<{ancho_estado}} "
    encabezado_der = "".join(f" {s:<{ancho_col}}" for s in alfabeto)
    print(f"  {encabezado_izq}|{encabezado_der}")

    # Separador con '+'
    sep_izq = "-" * len(encabezado_izq)
    sep_der = "-" * (len(encabezado_der) + 1)
    print(f"  {sep_izq}+{sep_der}")

    # Filas de transiciones
    for estado in estados:
        if estado == q0 and estado in finales:
            prefijo = "→* "
        elif estado == q0:
            prefijo = " → "
        elif estado in finales:
            prefijo = " * "
        else:
            prefijo = "   "

        izq = f"{prefijo} {estado:<{ancho_estado}} "
        der = "".join(f" {transiciones[(estado, s)]:<{ancho_col}}" for s in alfabeto)
        print(f"  {izq}|{der}")

    automata = {
        "Q": estados,
        "Sigma": alfabeto,
        "delta": transiciones,
        "q0": q0,
        "F": finales,
    }

    # Generar y abrir la gráfica
    graficar_automata(automata)

    return automata


def evaluar_palabra(automata, palabra):
    Sigma = automata["Sigma"]
    delta = automata["delta"]
    q0 = automata["q0"]
    F = automata["F"]

    estado_actual = q0
    recorrido = [q0]

    for i, simbolo in enumerate(palabra, start=1):
        if simbolo not in Sigma:
            return (
                False,
                None,
                f'el símbolo "{simbolo}" (posición {i}) no pertenece al alfabeto Σ = {{{", ".join(Sigma)}}}.',
            )
        estado_actual = delta[(estado_actual, simbolo)]
        recorrido.append(f"–{simbolo}→ {estado_actual}")

    es_reconocida = estado_actual in F
    recorrido_str = " ".join(recorrido)
    return es_reconocida, recorrido_str, estado_actual


def mostrar_palabras_conocidas(automata):
    print("\n=== MÓDULO 2: CINCO PALABRAS RECONOCIDAS ===")
    Q = automata["Q"]
    Sigma = automata["Sigma"]
    q0 = automata["q0"]
    F = automata["F"]

    q_str = ", ".join(Q)
    sigma_str = ", ".join(Sigma)
    f_str = ", ".join(F) if F else "∅"
    print(f"Autómata: M = ({{{q_str}}}, {{{sigma_str}}}, δ, {q0}, {{{f_str}}})\n")

    encontradas = []
    palabras_nivel_actual = [""]  # Nivel 0: empieza con la palabra vacía ε

    # Generar palabras desde longitud 0 hasta longitud 10 usando lógica pura
    for longitud in range(0, 11):
        for palabra in palabras_nivel_actual:
            reconocida, recorrido_str, _ = evaluar_palabra(automata, palabra)

            if reconocida:
                etiqueta = "ε" if palabra == "" else palabra
                encontradas.append((etiqueta, recorrido_str))
                if len(encontradas) == 5:
                    break

        if len(encontradas) == 5:
            break

        # Construir el siguiente nivel (longitud + 1) concatenando cada símbolo de Sigma
        if longitud < 10:
            siguiente_nivel = []
            for palabra in palabras_nivel_actual:
                for simbolo in Sigma:
                    siguiente_nivel.append(palabra + simbolo)
            palabras_nivel_actual = siguiente_nivel

    if len(encontradas) == 0:
        print("Este autómata no reconoce ninguna palabra de longitud menor o igual que 10.")
    else:
        for palabra_str, recorrido in encontradas:
            print(f"  {palabra_str:<12} recorrido: {recorrido}")

        if len(encontradas) < 5:
            print(
                f"\nEste autómata solo reconoce {len(encontradas)} palabra(s) de longitud menor o igual que 10."
            )


def probar_palabra(automata):
    print("\n=== MÓDULO 3: RECONOCIMIENTO DE PALABRAS ===")

    while True:
        palabra = input("Escriba una palabra (Enter sin texto = palabra vacía): ")
        palabra_mostrar = "ε" if palabra == "" else f'"{palabra}"'

        reconocida, recorrido_str, detalle = evaluar_palabra(automata, palabra)

        if recorrido_str is None:
            print(f"Resultado: la palabra {palabra_mostrar} NO es reconocida: {detalle}")
        else:
            estado_final = detalle
            print(f"Recorrido: {recorrido_str}")
            if reconocida:
                print(f"Estado final: {estado_final}, que es un estado final.")
                print(
                    f"Resultado: la palabra {palabra_mostrar} SÍ es reconocida por el autómata."
                )
            else:
                print(f"Estado final: {estado_final}, que no es un estado final.")
                print(
                    f"Resultado: la palabra {palabra_mostrar} NO es reconocida por el autómata."
                )

        while True:
            continuar = input("\n¿Desea probar otra palabra? (S/N): ").strip().upper()
            if continuar in ("S", "N"):
                break
            print("Por favor, responda S o N.")

        if continuar == "N":
            print("Volviendo al menú principal...")
            break


def main():
    opcion = 0
    automata = None

    while opcion != 4:
        mostrar_menu()
        try:
            opcion = int(input("Ingrese una opción: "))
        except ValueError:
            opcion = 0

        match opcion:
            case 1:
                automata = crear_automata()
            case 2:
                if automata is None:
                    print(
                        "Aviso: Primero debe construir un autómata en el Módulo 1 (Opción 1)."
                    )
                else:
                    mostrar_palabras_conocidas(automata)
            case 3:
                if automata is None:
                    print(
                        "Aviso: Primero debe construir un autómata en el Módulo 1 (Opción 1)."
                    )
                else:
                    probar_palabra(automata)
            case 4:
                print("Saliendo del programa...")
            case _:
                print("Opción inválida. Por favor, seleccione una opción válida.")


if __name__ == "__main__":
    main()